public interface Foo {
}
