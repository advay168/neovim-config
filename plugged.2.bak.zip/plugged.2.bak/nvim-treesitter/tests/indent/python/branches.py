a = [
    1, 2, 3]

b = [
    x + 1
    for x in range(3)]

c = [[[
    1
]]]

d = [[[
    4]]]

e = [[
    1], 2, 3]

def foo(x, y):
    pass

foo(
    a,
    b)

if (a and
        b):
    pass

if (a
        and b):
    pass
